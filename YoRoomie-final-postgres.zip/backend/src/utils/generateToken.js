const jwt = require("jsonwebtoken");

function generateToken(user) {
    return jwt.sign(
        {
            id: user.id,
            email: user.email,
        },
        "supersecretkey",
        { expiresIn: "7d" }
    );
}

module.exports = generateToken;