const express = require("express");
const router = express.Router();
const pool = require("../config/db");

router.get("/", async (req, res) => {
    try {
        const result = await pool.query("SELECT 1 AS ok");
        res.json({
            message: "API is working",
            database: result.rows[0].ok === 1 ? "connected" : "not connected",
        });
    } catch (error) {
        console.error("DB health error:", error);
        res.status(500).json({
            message: "API is running but database failed",
            error: String(error),
        });
    }
});

module.exports = router;
